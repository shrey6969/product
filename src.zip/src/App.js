import { useState } from "react";
import "./App.css";
function App(){
  const[list,setlist]=useState([]);
  const[value,setvalue]=useState("");

const addtocart=()=>{
  let temparr=list;
  temparr.push(value);
  setlist(temparr);
  setvalue("");
};

const deleteItem=(index)=>{
  let temp=list.filter((item,i)=> i!==index);
  setlist(temp);
};

return(
  <div className="app">
    <fieldset>
      <h1>add product to list</h1>
      <input type="text" value={value} onChange={(e)=> setvalue(e.target.value)} />
      <button onClick={addtocart}>click to add</button><br />

<h1>product catlog</h1>
<ol>
  {list.map((item,i)=> <li onClick={()=>deleteItem(i)}>{item}</li>)}
</ol>
<h2>click to delete</h2>
    </fieldset>

  </div>
);



}
export default App;